from fastapi import APIRouter
from schemas import UserResponse

router = APIRouter()

@router.get('/users/{id}', response_model=UserResponse)
def get_user(id: int):
    return {'id': id, 'name': 'Alice', 'email': 'alice@example.com'}
