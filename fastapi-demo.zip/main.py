from fastapi import FastAPI
from routes import router as user_router

app = FastAPI(title='FastAPI Demo App')
app.include_router(user_router)
